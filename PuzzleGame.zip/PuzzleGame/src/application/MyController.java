package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.event.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.*;

public class MyController {
	   @FXML
	   private Button restart;
	   @FXML
	   private Button lastStep;
	   @FXML
	   private Button setting;
	   @FXML
	   private Button hint;
	   @FXML
	   private Button solution;
	   
	   @FXML
	   private GridPane boardUI;
	   
	   @FXML
	   private Rectangle vCar0;
	   @FXML
	   private Rectangle vTruck1;
	   @FXML
	   private Rectangle vTruck2;
	   @FXML
	   private Rectangle vTruck3;
	   @FXML
	   private Rectangle vCar4;
	   @FXML
	   private Rectangle vCar5;
	   @FXML
	   private Rectangle vTruck6;
	   @FXML
	   private Rectangle vRedCar;
	   
	   private Board aboard;
	   private ArrayList<Vehicle> aVlist;
	   
	   private boolean vehicleSelected;
	   /*@Override URL location, ResourceBundle resources
	   public void initialize() {

		   vCar0.requestFocus();
		   vTruck1.requestFocus();
		   vTruck2.requestFocus();
		   vTruck3.requestFocus();
		   vCar4.requestFocus();
		   vCar5.requestFocus();
		   vTruck6.requestFocus();
		   vRedCar.requestFocus();  

	   }*/
	   
	   // when the mouse is pressed
	   @FXML
	   public void vehiclePressed(MouseEvent event) {
	       System.out.println("Vehicle pressed!");
	       // if it is rectangle
	       vehicleSelected = true;
	       ((Rectangle)event.getSource()).requestFocus();
	   }
	   
	   // When the key is pressed
	   @FXML
	   public void vehicleMove(KeyEvent event) {
	       System.out.println("Button Moved!");
	       if (vehicleSelected == true ) {
	    	   // get current row index, col index
	    	   Rectangle currR = (Rectangle)event.getSource();
	    	   Integer r = GridPane.getRowIndex((Rectangle)event.getSource());
	    	   Integer c = GridPane.getColumnIndex((Rectangle)event.getSource());
	    	   int row = r == null? 0:r;
	    	   int col = c == null? 0:c;
	    	   
	    	   
	    	   // compare with prevX prevY -> move horizontally or vertically
		       
		       // get the orientation of that object
		       
		       // check the validity of movement orientation
		       
		       // check the validity of the movement
		       // 		if there is other vehicle in the orientation
		       //		not beyond the border
		       
		       // if all test passed vehicle move with the key arrow
	    	   if (event.getCode() == KeyCode.UP ) {
	    		   boardUI.setRowIndex(currR, row - 1);
	    		   
	    	   } else if (event.getCode() == KeyCode.DOWN) {
	    		   boardUI.setRowIndex(currR, row + 1);
	    		   
	    	   } else if (event.getCode() == KeyCode.LEFT) {
	    		   boardUI.setColumnIndex(currR, col - 1);
	    		   
	    	   } else if (event.getCode() == KeyCode.RIGHT) {
	    		   boardUI.setColumnIndex(currR, col + 1);
	    	   }
	    	   
	       }
	       
	   }
	   
	   // when the mouse is released
	   @FXML
	   public void vehicleReleased(MouseEvent event) {
		   // get the vehicle that is selected
		   
		   // move the vehicle(update the board)
		   
		   
	   }
	   
	   @FXML
	   public void restart(ActionEvent event) {
		   System.out.println("restart clicked!");
		   
	   }
	   @FXML
	   public void backToLastStep(ActionEvent event) {
		   System.out.println("next Step clicked!");
	   }
	   @FXML
	   public void getHint(ActionEvent event) {
		   System.out.println("get hint clicked!");
	   }
	   @FXML
	   public void getSolution (ActionEvent event) {
		   System.out.println("get solution clicked!");
	   }
	   @FXML
	   public void getSetting(ActionEvent event) {
		   System.out.println("get setting clicked!");
	   }
	   @FXML
	   public void start(ActionEvent event) {
		   int rowindex = boardUI.getRowIndex(vCar0);
		   int colindex = boardUI.getColumnIndex(vCar0);
		   int rowspan = boardUI.getRowSpan(vCar0);
		   int colspan = boardUI.getColumnSpan(vCar0);
		   int orientation = 0;// horizontal
		   
		   // handle address
		   int[][] address = new int[2][2];
		   address[0][0] = colindex;
		   address[0][1] = rowindex;
		   address[1][0] = colindex + colspan -1;
		   address[1][1] = rowindex + rowspan -1;
		   
		   if(rowspan > 2 && colspan == 1) {
			   orientation = 1; // set as vertical
		   } 
		   aboard = new Board();
		   Vehicle vCar0 = new Vehicle (orientation, Math.max(rowspan, colspan));
		   vCar0.setAddress(address);
		   aboard.addVehicle(vCar0);
		   aVlist.add(vCar0);
	   }
}
